#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <arpa/inet.h>
#include <termios.h>
#include <fcntl.h>
#include <sys/file.h>
#include <signal.h>
 
#define DO 0xfd
#define WONT 0xfc
#define WILL 0xfb
#define DONT 0xfe
#define CMD 0xff
#define CMD_ECHO 1
#define CMD_WINDOW_SIZE 31

static unsigned int daemon_mode=0;

void negotiate(int sock, unsigned char *buf, int len)
{
	int i;
	 
	if(buf[1] == DO && buf[2] == CMD_WINDOW_SIZE)
	{
		unsigned char tmp1[10] = {255, 251, 31};
		if(send(sock, tmp1, 3 , 0) < 0)
		{
			exit(1);
		}
		 
		unsigned char tmp2[10] = {255, 250, 31, 0, 80, 0, 24, 255, 240};
		if(send(sock, tmp2, 9, 0) < 0)
		{
			exit(1);
		}
		return;
	}
	 
	for(i = 0; i < len; i++)
	{
		if(buf[i] == DO)
		{
			buf[i] = WONT;
		}
		else if(buf[i] == WILL)
		{
			buf[i] = DO;
		}
	}
 
	if(send(sock, buf, len , 0) < 0)
	{
		exit(1);
	}
}
 
static struct termios tin;
 
static void terminal_set(void)
{
	/* save terminal configuration */
	tcgetattr(STDIN_FILENO, &tin);
	 
	static struct termios tlocal;
	memcpy(&tlocal, &tin, sizeof(tin));
	cfmakeraw(&tlocal);
	tcsetattr(STDIN_FILENO,TCSANOW,&tlocal);
}
 
static void terminal_reset(void)
{
	/* restore terminal upon exit */
	tcsetattr(STDIN_FILENO,TCSANOW,&tin);
}

static void sig_handler(int sig_num)
{
	if(sig_num == SIGUSR1)
	{
		daemon_mode = 0;
	}
}

#define BUFLEN				(20)
#define CFG_LINE_LEN		(256)
#define TELNET_TCP_PORT		(12345)
#define MV_CPSS_SERVER_IP	"127.0.0.1"
#define DAEMON_SLEEP_USEC	(500000)
#define CLOSE_AND_RETURN(ret_val) \
		if(sock)	\
		{	\
			close(sock);	\
		}	\
		if(cfg_file)	\
		{	\
			fclose(cfg_file);	\
		} \
		if(output_file_fd>=0)	\
		{	\
			close(output_file_fd);	\
		} \
		return ret_val;
		
int main(int argc , char *argv[])
{
	char usage[] = "Usage: mv_pipe_config -c <config file> {-o <output file>} {-d}";
	int sock=0;
	struct sockaddr_in server;
	int c, len, nready, rv, ret, output_file_fd=-1;
	unsigned char buf[BUFLEN + 1];
	unsigned int c_flag=0, o_flag=0;
	char cfg_file_str[32], output_file_str[32], cfg_line[CFG_LINE_LEN];
	FILE *cfg_file = NULL;
	fd_set fds;
	struct timeval ts;
 
	if(argc < 3 || argc > 6)
	{
		printf("%s\n", usage);
		return -1;
	}
	
	optind = 0;
	while((c = getopt(argc, argv, "c:o:d")) != -1)
	{
		switch(c)
		{
			case 'c':
				c_flag = 1;
				memset(cfg_file_str, 0x0, sizeof(cfg_file_str));
				strncpy(cfg_file_str, optarg, sizeof(cfg_file_str)-1);
				break;
				
			case 'o':
				o_flag=1;
				memset(output_file_str, 0x0, sizeof(output_file_str));
				strncpy(output_file_str, optarg, sizeof(output_file_str)-1);
				break;
				
			case 'd':
				daemon_mode = 1;
				break;
				
			default:
				printf("%s\n", usage);
				return -2;
		}
	}
	
	if(c_flag==0)
	{
		printf("%s\n", usage);
		return -3;
	}

	if(daemon_mode)
	{
		daemon(0,0);
	}
	
	/* Create socket */
	sock = socket(AF_INET , SOCK_STREAM , 0);
	if(sock == -1)
	{
		perror("Could not create socket. Error\n");
		return -4;
	}
 
	server.sin_addr.s_addr = inet_addr(MV_CPSS_SERVER_IP);
	server.sin_family = AF_INET;
	server.sin_port = htons(TELNET_TCP_PORT);
 
	/* Connect to remote server */
	if(connect(sock, (struct sockaddr *)&server , sizeof(server)) < 0)
	{
		perror("connect failed. Error\n");
		close(sock);
		return -5;
	}

	/* set terminal */
	terminal_set();
	atexit(terminal_reset);
	
	/* signal handler */
	signal(SIGUSR1, sig_handler);
	
	do
	{
		if((cfg_file = fopen(cfg_file_str, "r")) != NULL)
		{
			if(o_flag)
			{
				if((output_file_fd = open(output_file_str, O_RDWR | O_CREAT)) < 0)
				{
					CLOSE_AND_RETURN(-6);
				}
				/* set lock */
				flock(output_file_fd, LOCK_EX);
			}
			
			while(1)
			{
				/* select setup */
				FD_ZERO(&fds);
				FD_SET(sock, &fds);
				ts.tv_sec = 0; // 1 second
				ts.tv_usec = 120000;
	 
				/* wait for data */
				nready = select(sock + 1, &fds, NULL, NULL, &ts);
				if(nready < 0)
				{
					perror("select. Error\n");
					CLOSE_AND_RETURN(-7);
				}
				else if(nready == 0)
				{
					if(cfg_file)
					{
						/* send commands */
						while(fgets(cfg_line, CFG_LINE_LEN, cfg_file))
						{
							send(sock, cfg_line, strlen(cfg_line), 0);
						}
						fclose(cfg_file);
						cfg_file = NULL;
					}
					else
					{
						break;
					}
				}
				else if(FD_ISSET(sock, &fds))
				{
					/* start by reading a single byte */
					if((rv = recv(sock , buf , 1 , 0)) < 0)
					{
						CLOSE_AND_RETURN(-8);
					}
					else if(rv == 0)
					{
						printf("Connection closed by the remote end\n\r");
						CLOSE_AND_RETURN(-9);
					}
		 
					if(buf[0] == CMD)
					{
						/* read 2 more bytes */
						len = recv(sock , buf + 1 , 2 , 0);
						if(len < 0)
						{
							CLOSE_AND_RETURN(-10);
						}
						else if(len == 0)
						{
							printf("Connection closed by the remote end\n\r");
							CLOSE_AND_RETURN(-11);
						}
						negotiate(sock, buf, 3);
					}
					else
					{
						len = 1;
						buf[len] = '\0';
						if(output_file_fd)
						{
							write(output_file_fd, &buf[0], 1);
						}
						else
						{
							printf("%s", buf);
							fflush(0);
						}
					}
				}
			}

			if(output_file_fd)
			{
				close(output_file_fd);
				output_file_fd = -1;
			}
		}
		else
		{
			printf("Could not open file: %s\n", cfg_file_str);
			CLOSE_AND_RETURN(-12);
		}
		
		if(daemon_mode)
		{
			usleep(DAEMON_SLEEP_USEC);
		}
	}while(daemon_mode);
	
	close(sock);
	
	return 0;
}